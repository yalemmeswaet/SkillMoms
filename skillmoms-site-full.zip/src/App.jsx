import React, { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BookOpen, Play, CheckCircle2, Globe2, Mail, Smartphone, Users, ShieldCheck, X } from "lucide-react";

// --- Simple mock data for the module catalog ---
const CATALOG = [
  {
    id: "digital-basics",
    title: "Digital Basics",
    level: "Beginner",
    duration: "45–60 min",
    tags: ["Digital Literacy", "Safety", "Productivity"],
    description:
      "Start here: essential skills for using devices, protecting your data, and working confidently online.",
    lessons: [
      { id: "d1", title: "Getting Comfortable with Your Device", length: "8:32" },
      { id: "d2", title: "Creating Strong Passwords & 2FA", length: "6:15" },
      { id: "d3", title: "Email & Calendar Basics", length: "9:41" },
      { id: "d4", title: "Cloud Storage & File Sharing", length: "7:50" },
      { id: "d5", title: "Online Safety for Families", length: "10:06" },
    ],
  },
  {
    id: "work-life-integration",
    title: "Work–Life Integration",
    level: "All Levels",
    duration: "~60 min",
    tags: ["Balance", "Planning", "Wellbeing"],
    description:
      "Evidence-informed strategies to plan your day, set boundaries, and find balance as a parent and professional.",
    lessons: [
      { id: "w1", title: "Weekly Planning that Sticks", length: "7:40" },
      { id: "w2", title: "Setting Boundaries with Confidence", length: "9:10" },
      { id: "w3", title: "Micro-habits for Energy", length: "8:58" },
      { id: "w4", title: "Support Networks & Childcare Options", length: "12:03" },
      { id: "w5", title: "Return-to-Work Playbook", length: "10:45" },
    ],
  },
  {
    id: "career-integration",
    title: "Career Integration for Newcomers",
    level: "Intermediate",
    duration: "~75 min",
    tags: ["Labor Market", "Germany", "Applications"],
    description:
      "Navigate the German labor market: CVs, recognition of qualifications, and job search platforms.",
    lessons: [
      { id: "c1", title: "Recognizing Foreign Qualifications (Anerkennung)", length: "11:12" },
      { id: "c2", title: "German-style CV & Cover Letter", length: "14:04" },
      { id: "c3", title: "Where to Find Roles (DE)", length: "9:21" },
      { id: "c4", title: "Interview Culture & Rights", length: "13:10" },
      { id: "c5", title: "Networking & Mentoring", length: "10:52" },
    ],
  },
];

// --- Utility for persistent local progress (in-browser) ---
const useProgress = () => {
  const [progress, setProgress] = useState(() => {
    try {
      const raw = localStorage.getItem("skillmoms_progress");
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });
  const update = (moduleId, lessonId, done) => {
    setProgress((p) => {
      const next = { ...p, [moduleId]: { ...(p[moduleId] || {}), [lessonId]: done } };
      localStorage.setItem("skillmoms_progress", JSON.stringify(next));
      return next;
    });
  };
  return { progress, update };
};

// --- Pill component ---
const Pill = ({ children }) => (
  <span className="inline-flex items-center rounded-full px-3 py-1 text-xs border">{children}</span>
);

// --- Modal player (placeholder video) ---
const LessonModal = ({ open, onClose, moduleTitle, lesson }) => (
  <AnimatePresence>
    {open && (
      <motion.div
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.div
          className="w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl"
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 20, opacity: 0 }}
        >
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="text-xl font-semibold">{moduleTitle}</h3>
              <p className="text-sm text-gray-600">{lesson?.title}</p>
            </div>
            <button onClick={onClose} aria-label="Close" className="p-2 hover:bg-gray-100 rounded-xl">
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Placeholder video area */}
          <div className="mt-4 aspect-video w-full overflow-hidden rounded-xl bg-gray-100 grid place-items-center">
            <Play className="h-12 w-12" />
          </div>

          <p className="mt-4 text-sm text-gray-600">
            This is a placeholder player. Replace with an embedded video host (e.g., Vimeo/YouTube) or your
            own file server. You can also attach downloadable PDFs and worksheets for each lesson.
          </p>
        </motion.div>
      </motion.div>
    )}
  </AnimatePresence>
);

// --- Main site ---
export default function SkillMomsSite() {
  const { progress, update } = useProgress();
  const [query, setQuery] = useState("");
  const [activeLesson, setActiveLesson] = useState(null);
  const [activeModule, setActiveModule] = useState(null);

  const filtered = useMemo(() => {
    if (!query) return CATALOG;
    const q = query.toLowerCase();
    return CATALOG.filter((m) =>
      [m.title, m.description, m.level, ...m.tags, ...m.lessons.map((l) => l.title)]
        .join(" ")
        .toLowerCase()
        .includes(q)
    );
  }, [query]);

  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* Nav */}
      <header className="sticky top-0 z-30 backdrop-blur bg-white/70 border-b">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 grid place-items-center rounded-2xl bg-gray-900 text-white font-bold">S</div>
            <span className="font-semibold">SkillMoms UG</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#mission" className="hover:opacity-70">Mission</a>
            <a href="#programs" className="hover:opacity-70">Programs</a>
            <a href="#catalog" className="hover:opacity-70">Training</a>
            <a href="#contact" className="hover:opacity-70">Contact</a>
          </nav>
          <a href="#catalog" className="text-sm rounded-xl px-3 py-2 border hover:bg-gray-50">Start learning</a>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-6xl px-4 py-16 md:py-24 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <motion.h1
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-3xl md:text-5xl font-bold leading-tight"
            >
              Digital learning & cultural platform empowering women and families
            </motion.h1>
            <p className="mt-4 text-gray-600 text-lg">
              We develop, implement, and promote programs in continuing education, digital empowerment, work–life
              balance, labor market integration, and cultural integration—with a focus on women, especially mothers and
              newcomers.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#catalog" className="rounded-xl px-4 py-2 bg-gray-900 text-white">Browse modules</a>
              <a href="#mission" className="rounded-xl px-4 py-2 border">Our mission</a>
            </div>
            <div className="mt-6 flex flex-wrap gap-2 text-xs text-gray-600">
              <Pill><ShieldCheck className="h-3.5 w-3.5 mr-1"/>Safe learning</Pill>
              <Pill><Smartphone className="h-3.5 w-3.5 mr-1"/>Mobile-first</Pill>
              <Pill><Globe2 className="h-3.5 w-3.5 mr-1"/>Multilingual-ready</Pill>
            </div>
          </div>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="relative">
            <div className="aspect-video w-full rounded-3xl bg-gray-100 grid place-items-center">
              <Users className="h-14 w-14"/>
            </div>
            <div className="absolute -bottom-4 -right-4 bg-white border rounded-2xl p-3 shadow-xl text-sm">
              <div className="flex items-center gap-2"><BookOpen className="h-4 w-4"/> 3 starter modules</div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Mission */}
      <section id="mission" className="border-t">
        <div className="mx-auto max-w-6xl px-4 py-14">
          <h2 className="text-2xl md:text-3xl font-semibold">Our mission</h2>
          <p className="mt-4 text-gray-700 leading-relaxed">
            The object of the company is the operation of a digital learning and cultural platform, as well as the
            development, implementation, and promotion of projects, services, and measures in the areas of continuing
            education, digital empowerment, work–life balance, labor market integration, and cultural integration. A
            particular focus is placed on empowering women — especially those with children and an immigration
            background — by supporting their personal and professional development, digital literacy, and integration
            into the labor market, including activities and transactions directly or indirectly suited to the purposes
            mentioned earlier.
          </p>
        </div>
      </section>

      {/* Programs highlights */}
      <section id="programs" className="border-t bg-gray-50">
        <div className="mx-auto max-w-6xl px-4 py-14">
          <h2 className="text-2xl md:text-3xl font-semibold">Programs & services</h2>
          <div className="mt-6 grid md:grid-cols-3 gap-4">
            {[
              {
                title: "Continuing education",
                desc: "Short, practical modules to grow digital skills and confidence.",
              },
              {
                title: "Labor market integration",
                desc: "CVs, interview prep, and pathways into meaningful work in Germany.",
              },
              {
                title: "Cultural integration",
                desc: "Community, language-friendly materials, and local orientation.",
              },
            ].map((c) => (
              <div key={c.title} className="rounded-2xl border bg-white p-5 shadow-sm">
                <h3 className="font-semibold">{c.title}</h3>
                <p className="mt-2 text-sm text-gray-600">{c.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Catalog */}
      <section id="catalog" className="border-t">
        <div className="mx-auto max-w-6xl px-4 py-14">
          <div className="flex items-end justify-between gap-4 flex-wrap">
            <div>
              <h2 className="text-2xl md:text-3xl font-semibold">Training modules</h2>
              <p className="text-gray-600 mt-1">Free starter collection. More courses coming soon.</p>
            </div>
            <div className="flex-1 md:flex-none">
              <label className="sr-only" htmlFor="search">Search modules</label>
              <input
                id="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search topics (e.g., CV, safety, cloud)"
                className="w-full md:w-80 rounded-xl border px-3 py-2"
              />
            </div>
          </div>

          <div className="mt-6 grid md:grid-cols-3 gap-4">
            {filtered.map((m) => {
              const total = m.lessons.length;
              const done = Object.values(progress[m.id] || {}).filter(Boolean).length;
              const pct = Math.round((done / total) * 100);
              return (
                <div key={m.id} className="rounded-2xl border p-5 shadow-sm">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-lg">{m.title}</h3>
                    <span className="text-xs text-gray-500">{m.level}</span>
                  </div>
                  <p className="mt-2 text-sm text-gray-600">{m.description}</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {m.tags.map((t) => (
                      <Pill key={t}>{t}</Pill>
                    ))}
                  </div>
                  <div className="mt-4 text-xs text-gray-600">Duration: {m.duration}</div>

                  <div className="mt-4 h-2 w-full rounded-full bg-gray-100 overflow-hidden">
                    <div className="h-full bg-gray-900" style={{ width: `${pct}%` }} />
                  </div>
                  <div className="mt-2 text-xs text-gray-600">Progress: {done}/{total} lessons</div>

                  <ul className="mt-4 space-y-2">
                    {m.lessons.map((l) => {
                      const checked = progress[m.id]?.[l.id] || false;
                      return (
                        <li key={l.id} className="flex items-center justify-between gap-2">
                          <button
                            onClick={() => { setActiveModule(m); setActiveLesson(l); }}
                            className="text-left flex-1 rounded-lg px-3 py-2 hover:bg-gray-50"
                          >
                            <div className="font-medium text-sm">{l.title}</div>
                            <div className="text-xs text-gray-500">{l.length}</div>
                          </button>
                          <button
                            onClick={() => update(m.id, l.id, !checked)}
                            aria-label={checked ? "Mark incomplete" : "Mark complete"}
                            className={`rounded-lg border px-2 py-2 ${checked ? "bg-green-50" : "bg-white"}`}
                          >
                            {checked ? <CheckCircle2 className="h-4 w-4"/> : <Play className="h-4 w-4"/>}
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="border-t bg-gray-50">
        <div className="mx-auto max-w-6xl px-4 py-14">
          <h2 className="text-2xl md:text-3xl font-semibold">Get in touch</h2>
          <p className="mt-2 text-sm text-gray-600 max-w-2xl">
            Interested in partnering, sponsoring, or bringing SkillMoms to your community? Send us a message. We welcome
            municipalities, NGOs, cultural centers, and employers.
          </p>
          <form className="mt-6 grid md:grid-cols-2 gap-4" onSubmit={(e)=>e.preventDefault()}>
            <input required placeholder="Your name" className="rounded-xl border px-3 py-2"/>
            <input required type="email" placeholder="Email" className="rounded-xl border px-3 py-2"/>
            <input placeholder="Organization (optional)" className="rounded-xl border px-3 py-2 md:col-span-2"/>
            <textarea required placeholder="How can we help?" className="rounded-xl border px-3 py-2 md:col-span-2 min-h-[120px]"/>
            <button type="submit" className="rounded-xl bg-gray-900 text-white px-4 py-2 flex items-center gap-2 w-fit">
              <Mail className="h-4 w-4"/> Send message
            </button>
          </form>

          <p className="mt-4 text-xs text-gray-500">
            By sending, you agree to our privacy policy. We keep your data safe and never sell it.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t">
        <div className="mx-auto max-w-6xl px-4 py-10 text-sm text-gray-600">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <div className="font-semibold text-gray-900">SkillMoms UG</div>
              <div className="mt-1">© {new Date().getFullYear()} SkillMoms UG. All rights reserved.</div>
            </div>
            <div className="flex gap-6">
              <a href="#" className="hover:opacity-70">Impressum</a>
              <a href="#" className="hover:opacity-70">Datenschutz</a>
              <a href="#contact" className="hover:opacity-70">Contact</a>
            </div>
          </div>
        </div>
      </footer>

      <LessonModal
        open={!!activeLesson}
        onClose={() => { setActiveLesson(null); setActiveModule(null); }}
        moduleTitle={activeModule?.title}
        lesson={activeLesson}
      />
    </div>
  );
}
